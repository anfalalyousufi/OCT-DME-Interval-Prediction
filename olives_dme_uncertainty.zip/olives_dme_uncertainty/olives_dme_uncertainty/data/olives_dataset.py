"""
OLIVES Dataset loader for injection-interval prediction.

REQUIRED COLUMNS (rename your CSV to match, or edit COLUMN_MAP below):
    patient_id   : unique eye/patient identifier (OLIVES eyes are the right unit,
                    not patients, since some patients contribute both eyes)
    visit_week   : integer week number of this visit (0, 4, 8, 12, ...)
    oct_path     : path to the OCT volume / central B-scan image for this visit
    bcva         : best-corrected visual acuity (float)
    cst          : central subfield thickness in microns (float)
    injected     : 1 if an anti-VEGF injection was given at this visit, else 0
    biomarker_*  : any number of binary biomarker columns, e.g.
                   biomarker_irf, biomarker_srf, biomarker_drt_dme, biomarker_ez_disruption

The dataset builds one training example per visit i (excluding each eye's
last visit, which has no "next visit" to supervise against):
    input  = OCT image at visit i + tabular vector at visit i (+ short history)
    target = (visit_week[i+1] - visit_week[i])   -> weeks until next visit/injection

If your export instead gives injection *dates* rather than a fixed visit
schedule, compute visit_week as (date - baseline_date).days // 7 before
loading.
"""

import os
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms

# Edit this if your CSV uses different column names.
COLUMN_MAP = {
    "patient_id": "patient_id",
    "visit_week": "visit_week",
    "oct_path": "oct_path",
    "bcva": "bcva",
    "cst": "cst",
    "injected": "injected",
}

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


@dataclass
class OlivesConfig:
    csv_path: str
    image_root: str
    image_size: int = 224
    biomarker_prefix: str = "biomarker_"
    history_length: int = 2  # how many prior visits' tabular data to include
    train: bool = True


class OlivesInjectionIntervalDataset(Dataset):
    """One example per (eye, visit) pair with a valid next visit."""

    def __init__(self, config: OlivesConfig, patient_ids: list[str] | None = None):
        self.cfg = config
        df = pd.read_csv(config.csv_path)
        df = df.rename(columns={v: k for k, v in COLUMN_MAP.items()})

        missing = [c for c in COLUMN_MAP if c not in df.columns]
        if missing:
            raise ValueError(
                f"CSV is missing expected columns after remapping: {missing}. "
                f"Edit COLUMN_MAP at the top of olives_dataset.py to match your export."
            )

        self.biomarker_cols = [c for c in df.columns if c.startswith(config.biomarker_prefix)]

        if patient_ids is not None:
            df = df[df["patient_id"].isin(patient_ids)]

        df = df.sort_values(["patient_id", "visit_week"]).reset_index(drop=True)
        self.df = df
        self.examples = self._build_examples(df)

        tfm = [transforms.Resize((config.image_size, config.image_size))]
        if config.train:
            tfm += [
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.ColorJitter(brightness=0.1, contrast=0.1),
            ]
        tfm += [transforms.ToTensor(), transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD)]
        self.transform = transforms.Compose(tfm)

    def _build_examples(self, df: pd.DataFrame) -> list[dict]:
        """One example per visit that has a subsequent visit to predict."""
        examples = []
        for pid, group in df.groupby("patient_id"):
            group = group.reset_index(drop=True)
            for i in range(len(group) - 1):
                target_weeks = group.loc[i + 1, "visit_week"] - group.loc[i, "visit_week"]
                if target_weeks <= 0:
                    continue  # skip malformed/duplicate-visit rows
                history_idx = list(range(max(0, i - self.cfg.history_length + 1), i + 1))
                examples.append(
                    {
                        "patient_id": pid,
                        "row_idx": group.loc[i].name,
                        "history_rows": group.loc[history_idx],
                        "target_weeks": float(target_weeks),
                        "injected_next": int(group.loc[i + 1, "injected"]),
                    }
                )
        return examples

    def _tabular_vector(self, history_rows: pd.DataFrame) -> np.ndarray:
        """Flatten BCVA/CST/biomarkers from the last `history_length` visits.

        Pads with zeros at the start of a patient's timeline where fewer
        than history_length prior visits exist.
        """
        feats = []
        pad_needed = self.cfg.history_length - len(history_rows)
        for _ in range(pad_needed):
            feats.append(np.zeros(2 + len(self.biomarker_cols), dtype=np.float32))
        for _, row in history_rows.iterrows():
            vec = [row["bcva"], row["cst"]] + [row.get(c, 0.0) for c in self.biomarker_cols]
            feats.append(np.array(vec, dtype=np.float32))
        return np.concatenate(feats)

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> dict:
        ex = self.examples[idx]
        current_row = ex["history_rows"].iloc[-1]

        img_path = os.path.join(self.cfg.image_root, current_row["oct_path"])
        image = Image.open(img_path).convert("RGB")
        image = self.transform(image)

        tabular = torch.from_numpy(self._tabular_vector(ex["history_rows"]))

        return {
            "image": image,
            "tabular": tabular,
            "target_weeks": torch.tensor(ex["target_weeks"], dtype=torch.float32),
            "injected_next": torch.tensor(ex["injected_next"], dtype=torch.long),
            "patient_id": ex["patient_id"],
        }

    @property
    def tabular_dim(self) -> int:
        return self.cfg.history_length * (2 + len(self.biomarker_cols))


def patient_level_split(csv_path: str, val_frac=0.15, test_frac=0.15, seed=0):
    """Split by eye/patient ID, never by visit, to avoid leakage across
    an eye's own longitudinal visits landing in both train and test."""
    df = pd.read_csv(csv_path).rename(columns={v: k for k, v in COLUMN_MAP.items()})
    ids = df["patient_id"].unique()
    rng = np.random.default_rng(seed)
    rng.shuffle(ids)
    n = len(ids)
    n_val, n_test = int(n * val_frac), int(n * test_frac)
    test_ids = ids[:n_test]
    val_ids = ids[n_test : n_test + n_val]
    train_ids = ids[n_test + n_val :]
    return list(train_ids), list(val_ids), list(test_ids)
