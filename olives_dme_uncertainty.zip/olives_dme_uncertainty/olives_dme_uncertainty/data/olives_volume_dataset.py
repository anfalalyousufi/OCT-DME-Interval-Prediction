"""
Volume-level OLIVES loader. Loads the FULL OCT volume (all B-scans) for a
visit instead of a single B-scan.

REQUIRED COLUMNS (see data/olives_dataset.py for the full list) plus:
    oct_dir      : path to a folder containing that visit's B-scan images,
                   OR path to a single multi-page volume file (.npy / .tiff)
                   Edit `load_volume()` below to match whichever your export uses.

Every OLIVES volume has ~49 B-scans, but real exports vary slightly in
count per visit/device. We standardize to a fixed depth D by uniformly
resampling slice indices — this is the "twist" needed to batch volumes of
different lengths together, not a twist on the data itself.
"""

import os

import numpy as np
import pandas as pd
import torch
from PIL import Image
from torch.utils.data import Dataset
from torchvision import transforms

from data.olives_dataset import COLUMN_MAP  # reuse the same column remapping

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


def load_volume(oct_dir: str, target_depth: int, image_size: int) -> torch.Tensor:
    """Returns a (D, 3, H, W) float tensor for one OCT volume.

    Assumes `oct_dir` is a folder of B-scan images named so that sorting
    alphabetically = sorting by depth (e.g. scan_001.png ... scan_049.png).
    If your export instead gives one .npy volume file, replace the body of
    this function with: volume = np.load(oct_dir)  # shape (D, H, W)
    """
    files = sorted(f for f in os.listdir(oct_dir) if f.lower().endswith((".png", ".jpg", ".jpeg", ".tiff", ".tif")))
    if not files:
        raise FileNotFoundError(f"No B-scan images found in {oct_dir}")

    n_available = len(files)
    # Uniformly resample to target_depth indices so every volume batches together
    # regardless of how many B-scans the original scan actually had.
    idxs = np.linspace(0, n_available - 1, target_depth).round().astype(int)

    tfm = transforms.Compose(
        [
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ]
    )

    slices = []
    for i in idxs:
        img = Image.open(os.path.join(oct_dir, files[i])).convert("RGB")
        slices.append(tfm(img))
    return torch.stack(slices, dim=0)  # (D, 3, H, W)


class OlivesVolumeDataset(Dataset):
    """One example per (eye, visit) pair with a valid next visit, using the
    FULL OCT volume rather than a single B-scan."""

    def __init__(
        self,
        csv_path: str,
        volume_root: str,
        patient_ids: list[str] | None = None,
        target_depth: int = 32,
        image_size: int = 128,  # smaller than the 2D pipeline's 224 - volumes are memory-heavy
        biomarker_prefix: str = "biomarker_",
        history_length: int = 2,
    ):
        self.volume_root = volume_root
        self.target_depth = target_depth
        self.image_size = image_size
        self.history_length = history_length

        df = pd.read_csv(csv_path).rename(columns={v: k for k, v in COLUMN_MAP.items()})
        if "oct_dir" not in df.columns:
            raise ValueError(
                "CSV needs an 'oct_dir' column pointing to each visit's B-scan folder. "
                "Add it, or edit COLUMN_MAP / this class to match your export."
            )

        self.biomarker_cols = [c for c in df.columns if c.startswith(biomarker_prefix)]

        if patient_ids is not None:
            df = df[df["patient_id"].isin(patient_ids)]

        df = df.sort_values(["patient_id", "visit_week"]).reset_index(drop=True)
        self.df = df
        self.examples = self._build_examples(df)

    def _build_examples(self, df: pd.DataFrame) -> list[dict]:
        examples = []
        for pid, group in df.groupby("patient_id"):
            group = group.reset_index(drop=True)
            for i in range(len(group) - 1):
                target_weeks = group.loc[i + 1, "visit_week"] - group.loc[i, "visit_week"]
                if target_weeks <= 0:
                    continue
                history_idx = list(range(max(0, i - self.history_length + 1), i + 1))
                examples.append(
                    {
                        "patient_id": pid,
                        "history_rows": group.loc[history_idx],
                        "target_weeks": float(target_weeks),
                        "injected_next": int(group.loc[i + 1, "injected"]),
                    }
                )
        return examples

    def _tabular_vector(self, history_rows: pd.DataFrame) -> np.ndarray:
        feats = []
        pad_needed = self.history_length - len(history_rows)
        for _ in range(pad_needed):
            feats.append(np.zeros(2 + len(self.biomarker_cols), dtype=np.float32))
        for _, row in history_rows.iterrows():
            vec = [row["bcva"], row["cst"]] + [row.get(c, 0.0) for c in self.biomarker_cols]
            feats.append(np.array(vec, dtype=np.float32))
        return np.concatenate(feats)

    def __len__(self) -> int:
        return len(self.examples)

    def __getitem__(self, idx: int) -> dict:
        ex = self.examples[idx]
        current_row = ex["history_rows"].iloc[-1]

        oct_dir = os.path.join(self.volume_root, current_row["oct_dir"])
        volume = load_volume(oct_dir, self.target_depth, self.image_size)  # (D, 3, H, W)

        tabular = torch.from_numpy(self._tabular_vector(ex["history_rows"]))

        return {
            "volume": volume,
            "tabular": tabular,
            "target_weeks": torch.tensor(ex["target_weeks"], dtype=torch.float32),
            "injected_next": torch.tensor(ex["injected_next"], dtype=torch.long),
            "patient_id": ex["patient_id"],
        }

    @property
    def tabular_dim(self) -> int:
        return self.history_length * (2 + len(self.biomarker_cols))
