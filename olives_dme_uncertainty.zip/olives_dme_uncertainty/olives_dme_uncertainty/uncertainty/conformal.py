"""
Model-agnostic uncertainty wrappers for regression.

Both methods need a held-out CALIBRATION split that the model never trained
on (distinct from train/val/test). A common recipe: carve your existing
validation split in half — one half for early stopping, one half for
conformal calibration — so you don't need yet another patient-level split.

1. SplitConformalRegressor
   - Wraps ANY point-prediction model (e.g. FusionRegressor with
     quantile_mode=False).
   - Produces fixed-width intervals: [pred - q, pred + q], where q is the
     (1-alpha) quantile of calibration-set residuals.
   - Simple, fast, guaranteed marginal coverage. Downside: same interval
     width for every patient, easy and hard cases alike.

2. ConformalizedQuantileRegressor (CQR)
   - Wraps a model trained with quantile_mode=True + pinball_loss (see
     models/fusion_model.py), which already outputs [q_low, q_median, q_high]
     per sample.
   - Conformal calibration then adjusts those per-sample quantiles by a
     single scalar correction, giving intervals that are narrow for
     confident cases and wide for ambiguous ones while still holding the
     coverage guarantee.
   - This is the one worth using for the actual project — it's the
     behavior you want from a treat-and-extend decision-support tool.
"""

from dataclasses import dataclass

import numpy as np


@dataclass
class ConformalResult:
    lower: np.ndarray
    upper: np.ndarray
    point: np.ndarray

    def coverage(self, y_true: np.ndarray) -> float:
        return float(np.mean((y_true >= self.lower) & (y_true <= self.upper)))

    def mean_width(self) -> float:
        return float(np.mean(self.upper - self.lower))


class SplitConformalRegressor:
    def __init__(self, alpha: float = 0.1):
        self.alpha = alpha  # 1 - alpha = target coverage, e.g. 0.1 -> 90%
        self.q_hat = None

    def calibrate(self, calib_preds: np.ndarray, calib_targets: np.ndarray) -> None:
        residuals = np.abs(calib_targets - calib_preds)
        n = len(residuals)
        # finite-sample corrected quantile level (Vovk et al. split conformal)
        level = np.ceil((n + 1) * (1 - self.alpha)) / n
        level = min(level, 1.0)
        self.q_hat = np.quantile(residuals, level)

    def predict(self, point_preds: np.ndarray) -> ConformalResult:
        if self.q_hat is None:
            raise RuntimeError("Call .calibrate() before .predict().")
        lower = np.clip(point_preds - self.q_hat, a_min=0, a_max=None)
        upper = point_preds + self.q_hat
        return ConformalResult(lower=lower, upper=upper, point=point_preds)


class ConformalizedQuantileRegressor:
    """CQR per Romano, Patterson & Candes (2019). Wraps a model that already
    outputs (q_low, q_high) at, e.g., the 0.1 / 0.9 quantiles."""

    def __init__(self, alpha: float = 0.1):
        self.alpha = alpha
        self.q_hat = None

    def calibrate(self, calib_q_low: np.ndarray, calib_q_high: np.ndarray, calib_targets: np.ndarray) -> None:
        # nonconformity score: how far outside the predicted [low, high] the true value fell
        scores = np.maximum(calib_q_low - calib_targets, calib_targets - calib_q_high)
        n = len(scores)
        level = np.ceil((n + 1) * (1 - self.alpha)) / n
        level = min(level, 1.0)
        self.q_hat = np.quantile(scores, level)

    def predict(self, q_low: np.ndarray, q_high: np.ndarray, point: np.ndarray | None = None) -> ConformalResult:
        if self.q_hat is None:
            raise RuntimeError("Call .calibrate() before .predict().")
        lower = np.clip(q_low - self.q_hat, a_min=0, a_max=None)
        upper = q_high + self.q_hat
        if point is None:
            point = (q_low + q_high) / 2
        return ConformalResult(lower=lower, upper=upper, point=point)
