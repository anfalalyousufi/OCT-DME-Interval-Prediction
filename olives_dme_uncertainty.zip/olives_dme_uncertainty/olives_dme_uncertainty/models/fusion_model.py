"""
Fusion model: image backbone (OCT) + tabular MLP (BCVA/CST/biomarkers) ->
concatenated -> regression head predicting weeks-until-next-visit.

To switch to the classification framing ("inject now" vs "extend interval")
instead of regression:
  1. Change `out_features=1` -> `out_features=2` in the head.
  2. Change the loss in train.py from MSE/L1 to CrossEntropyLoss.
  3. Swap the `injected_next` label in for `target_weeks` as the training target.
The backbone and fusion logic don't need to change either way.
"""

import torch
import torch.nn as nn
import torchvision.models as tv_models


class ImageBackbone(nn.Module):
    """Thin wrapper so you can swap ResNet/EfficientNet/ViT with one line."""

    def __init__(self, name: str = "resnet18", pretrained: bool = True):
        super().__init__()
        if name == "resnet18":
            net = tv_models.resnet18(weights="IMAGENET1K_V1" if pretrained else None)
            self.out_dim = net.fc.in_features
            net.fc = nn.Identity()
        elif name == "resnet50":
            net = tv_models.resnet50(weights="IMAGENET1K_V2" if pretrained else None)
            self.out_dim = net.fc.in_features
            net.fc = nn.Identity()
        elif name == "efficientnet_b0":
            net = tv_models.efficientnet_b0(weights="IMAGENET1K_V1" if pretrained else None)
            self.out_dim = net.classifier[1].in_features
            net.classifier = nn.Identity()
        elif name == "vit_b_16":
            net = tv_models.vit_b_16(weights="IMAGENET1K_V1" if pretrained else None)
            self.out_dim = net.heads.head.in_features
            net.heads = nn.Identity()
        else:
            raise ValueError(f"Unsupported backbone: {name}")
        self.net = net

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class TabularEncoder(nn.Module):
    def __init__(self, in_dim: int, hidden_dim: int = 64, out_dim: int = 32):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.BatchNorm1d(hidden_dim),
            nn.Dropout(0.2),
            nn.Linear(hidden_dim, out_dim),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.mlp(x)


class FusionRegressor(nn.Module):
    """image + tabular -> single scalar: predicted weeks until next visit.

    Outputs BOTH a point prediction and, optionally, lower/upper quantile
    predictions in the same forward pass (used by CQR in uncertainty/conformal.py).
    Set `quantile_mode=True` to get the 3-output version.
    """

    def __init__(
        self,
        tabular_dim: int,
        backbone_name: str = "resnet18",
        pretrained: bool = True,
        quantile_mode: bool = False,
    ):
        super().__init__()
        self.backbone = ImageBackbone(backbone_name, pretrained)
        self.tab_encoder = TabularEncoder(tabular_dim)
        fused_dim = self.backbone.out_dim + self.tab_encoder.mlp[-2].out_features
        self.quantile_mode = quantile_mode
        n_out = 3 if quantile_mode else 1  # [lower, median, upper] or [point]

        self.head = nn.Sequential(
            nn.Linear(fused_dim, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, n_out),
        )

    def forward(self, image: torch.Tensor, tabular: torch.Tensor) -> torch.Tensor:
        img_feat = self.backbone(image)
        tab_feat = self.tab_encoder(tabular)
        fused = torch.cat([img_feat, tab_feat], dim=1)
        out = self.head(fused)
        # weeks-until-next-visit is strictly positive -> softplus keeps outputs valid
        return torch.nn.functional.softplus(out)


def pinball_loss(preds: torch.Tensor, target: torch.Tensor, quantiles=(0.1, 0.5, 0.9)) -> torch.Tensor:
    """Quantile ('pinball') loss for the 3-output quantile_mode head.
    preds: (batch, 3) = [q_low, q_median, q_high]; target: (batch,)
    """
    losses = []
    for i, q in enumerate(quantiles):
        err = target - preds[:, i]
        losses.append(torch.max((q - 1) * err, q * err))
    return torch.stack(losses, dim=1).mean()
