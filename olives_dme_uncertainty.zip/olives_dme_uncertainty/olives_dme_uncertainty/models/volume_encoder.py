"""
Two ways to encode a full OCT volume (D, 3, H, W) into a single feature
vector, matching the two families of papers in the literature review:

1. Slice2DAggregator ("the pragmatic choice")
   Runs a 2D pretrained CNN independently on every B-scan, then aggregates
   across depth with attention pooling (a small MIL - multiple instance
   learning - head). This is the SLIVER-net-style approach: it reuses
   ImageNet pretraining (no 3D pretrained backbone exists at that scale),
   is far cheaper to train, and as a bonus the attention weights tell you
   WHICH B-scans the model found most informative - a free interpretability
   signal you can show a clinician ("the model focused on these 6 slices").
   Start here.

2. Conv3DEncoder ("the literature-accurate choice")
   A real 3D CNN (Conv3d/BatchNorm3d/MaxPool3d blocks) that convolves
   across x, y, AND depth jointly, matching the architecture style used in
   the glaucoma 3D-CNN and AMD 3D-ensemble papers from the review. No
   pretrained weights available at this scale, so it needs more data and
   more epochs to converge than the slice-aggregation model. Try this once
   the slice-aggregation pipeline is working end-to-end and you want to see
   whether true volumetric convolution beats it on your task.
"""

import torch
import torch.nn as nn
import torchvision.models as tv_models


class SliceEncoder2D(nn.Module):
    """Applies one shared 2D CNN to every slice, independently."""

    def __init__(self, name: str = "resnet18", pretrained: bool = True):
        super().__init__()
        if name == "resnet18":
            net = tv_models.resnet18(weights="IMAGENET1K_V1" if pretrained else None)
            self.out_dim = net.fc.in_features
            net.fc = nn.Identity()
        elif name == "efficientnet_b0":
            net = tv_models.efficientnet_b0(weights="IMAGENET1K_V1" if pretrained else None)
            self.out_dim = net.classifier[1].in_features
            net.classifier = nn.Identity()
        else:
            raise ValueError(f"Unsupported slice backbone: {name}")
        self.net = net

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B*D, 3, H, W) -> (B*D, out_dim)
        return self.net(x)


class AttentionPool(nn.Module):
    """Learned attention pooling across the depth (slice) dimension —
    standard multiple-instance-learning (MIL) head. Returns both the
    pooled feature and the per-slice attention weights for interpretability.
    """

    def __init__(self, feat_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.attn = nn.Sequential(
            nn.Linear(feat_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, slice_feats: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        # slice_feats: (B, D, feat_dim)
        scores = self.attn(slice_feats).squeeze(-1)          # (B, D)
        weights = torch.softmax(scores, dim=1)                # (B, D)
        pooled = torch.einsum("bd,bdf->bf", weights, slice_feats)  # (B, feat_dim)
        return pooled, weights


class Slice2DAggregator(nn.Module):
    """Full volume -> per-slice 2D features -> attention-pooled volume feature."""

    def __init__(self, backbone_name: str = "resnet18", pretrained: bool = True):
        super().__init__()
        self.slice_encoder = SliceEncoder2D(backbone_name, pretrained)
        self.pool = AttentionPool(self.slice_encoder.out_dim)
        self.out_dim = self.slice_encoder.out_dim

    def forward(self, volume: torch.Tensor, return_attention: bool = False):
        # volume: (B, D, 3, H, W)
        B, D, C, H, W = volume.shape
        flat = volume.view(B * D, C, H, W)
        feats = self.slice_encoder(flat).view(B, D, -1)  # (B, D, feat_dim)
        pooled, weights = self.pool(feats)
        if return_attention:
            return pooled, weights
        return pooled


class Conv3DEncoder(nn.Module):
    """A compact 3D CNN over the whole volume, in the style of the
    glaucoma/AMD 3D-CNN papers: repeated Conv3d -> BatchNorm3d -> ReLU ->
    MaxPool3d blocks, ending in global average pooling.

    No pretrained weights exist at this scale for OCT, so this trains from
    scratch — expect it to need more epochs and more data than the
    slice-aggregation model to reach the same accuracy.
    """

    def __init__(self, in_channels: int = 3, base_channels: int = 16, out_dim: int = 256):
        super().__init__()

        def block(c_in, c_out):
            return nn.Sequential(
                nn.Conv3d(c_in, c_out, kernel_size=3, padding=1),
                nn.BatchNorm3d(c_out),
                nn.ReLU(inplace=True),
                nn.MaxPool3d(kernel_size=2),
            )

        self.features = nn.Sequential(
            block(in_channels, base_channels),        # D,H,W -> D/2,H/2,W/2
            block(base_channels, base_channels * 2),    # -> D/4,H/4,W/4
            block(base_channels * 2, base_channels * 4),  # -> D/8,H/8,W/8
            block(base_channels * 4, base_channels * 8),  # -> D/16,H/16,W/16
        )
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.proj = nn.Linear(base_channels * 8, out_dim)
        self.out_dim = out_dim

    def forward(self, volume: torch.Tensor) -> torch.Tensor:
        # volume: (B, D, 3, H, W) -> Conv3d wants (B, C, D, H, W)
        x = volume.permute(0, 2, 1, 3, 4)
        x = self.features(x)
        x = self.pool(x).flatten(1)
        return self.proj(x)
