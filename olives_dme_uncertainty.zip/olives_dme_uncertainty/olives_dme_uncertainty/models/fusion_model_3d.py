"""
Volume-level fusion model. Same fusion logic as models/fusion_model.py
(image branch + tabular branch -> concat -> regression head) but the image
branch now consumes a full OCT volume via one of the two encoders in
models/volume_encoder.py, chosen with `encoder_type`.
"""

import torch
import torch.nn as nn

from models.fusion_model import TabularEncoder, pinball_loss  # reuse, unchanged
from models.volume_encoder import Conv3DEncoder, Slice2DAggregator

__all__ = ["VolumeFusionRegressor", "pinball_loss"]


class VolumeFusionRegressor(nn.Module):
    def __init__(
        self,
        tabular_dim: int,
        encoder_type: str = "slice2d",  # "slice2d" | "conv3d"
        backbone_name: str = "resnet18",  # only used when encoder_type="slice2d"
        pretrained: bool = True,
        quantile_mode: bool = False,
    ):
        super().__init__()
        if encoder_type == "slice2d":
            self.volume_encoder = Slice2DAggregator(backbone_name, pretrained)
        elif encoder_type == "conv3d":
            self.volume_encoder = Conv3DEncoder()
        else:
            raise ValueError(f"encoder_type must be 'slice2d' or 'conv3d', got {encoder_type}")

        self.encoder_type = encoder_type
        self.tab_encoder = TabularEncoder(tabular_dim)
        fused_dim = self.volume_encoder.out_dim + self.tab_encoder.mlp[-2].out_features
        self.quantile_mode = quantile_mode
        n_out = 3 if quantile_mode else 1

        self.head = nn.Sequential(
            nn.Linear(fused_dim, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, n_out),
        )

    def forward(self, volume: torch.Tensor, tabular: torch.Tensor, return_attention: bool = False):
        attn_weights = None
        if self.encoder_type == "slice2d" and return_attention:
            vol_feat, attn_weights = self.volume_encoder(volume, return_attention=True)
        else:
            vol_feat = self.volume_encoder(volume)

        tab_feat = self.tab_encoder(tabular)
        fused = torch.cat([vol_feat, tab_feat], dim=1)
        out = torch.nn.functional.softplus(self.head(fused))

        if return_attention:
            return out, attn_weights
        return out
